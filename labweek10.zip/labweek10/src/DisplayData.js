import React, { Component } from 'react'
import './App.css';

class DisplayData extends Component {
    state = {
        firstName: '',email: '' ,address:'', address2:'', city:'', province:'', postalcode:'',
        showName: false,

        
    
      }

      displayEmailHandler = (e) => {
        let updatedEmail = e.target.value;
        this.setState({ email: updatedEmail}); 
      }
    
      displayNameHandler = (e) => {
        let updatedName = e.target.value;
        this.setState({ firstName: updatedName});
      }
      displayaddress = (e) => {
        let updatedaddress = e.target.value;
        this.setState({ address: updatedaddress}); 
      }

      displayaddress2 = (e) => {
        let updatedaddress2 = e.target.value;
        this.setState({ address2: updatedaddress2});
      }

      displayCity = (e) => {
        let updatedcity = e.target.value;
        this.setState({ city: updatedcity});
      }

      displayProvince = (e) => {
        let updatedprovince = e.target.value;
        this.setState({ province: updatedprovince});
      }
      displayPostalCode = (e) => {
        let updatedpostalcode = e.target.value;
        this.setState({ postalcode: updatedpostalcode});
      }
    
      handleSubmit = (e) => {
        e.preventDefault();
        this.setState({
          showName: true,
        });
      }
    
      render() {
        return (
          <div>
              
            <form onSubmit={this.handleSubmit}>
            <fieldset >
              <label >Full Name: </label>
              <input placeholder = "Enter FullName" type="text" name="firstName" onChange={this.displayNameHandler} value={this.state.firstName}/>&nbsp;&nbsp;&nbsp;
              <label>Email: </label>
              <input placeholder = "Enter Email" type="text" name="email" onChange={this.displayEmailHandler} value={this.state.email} />
              <br></br><br></br>
              <label>Address: </label>
              <input placeholder = "1234 Main ST" type="text" name="address" onChange={this.displayaddress} value={this.state.address} /><br></br><br></br>
              <label>Address2: </label>
              <input placeholder = "1234 Main ST" type="text" name="address2" onChange={this.displayaddress2} value={this.state.address2}/>
              <br></br><br></br>
              <label>City: </label>
              <input placeholder = "Toronto" type="text" name="city" onChange={this.displayCity} value={this.state.city}/>&nbsp;&nbsp;&nbsp;
              <label>
                  Province: 
                  <select
                  name="province"
                  value={this.state.province}
                  onChange={this.displayProvince}>
                      <option value="Ontario">Ontario</option>
                      <option value="British Coloumbia">British Columbia</option>
                      <option value="Qubec">Qubec</option>
                      <option value="Alberta">Alberta</option>
                    </select>
                </label>&nbsp;&nbsp;&nbsp;
                <label>Postal Code: </label>
                <input placeholder = "M12 7YU" type="text" name="postalcode" onChange={this.displayPostalCode} value={this.state.postalcode}/>
              <br></br><br></br><button type="submit" onClick={this.handleSubmit}>Submit</button>
              </fieldset>
              {this.state.showName && <p className="green-text">FirstName:  {this.state.firstName}</p>}
              {this.state.showName && <p className="green-text">Email:  {this.state.email}</p>}
              {this.state.showName && <p className="green-text">Address:  {this.state.address}</p>}
              {this.state.showName && <p className="green-text">Address2:  {this.state.address2}</p>}
              {this.state.showName && <p className="green-text">City:  {this.state.city}</p>}
              {this.state.showName && <p className="green-text">Province:  {this.state.province}</p>}
            </form>
            
          </div>
        );
      }
    }
    export default DisplayData;


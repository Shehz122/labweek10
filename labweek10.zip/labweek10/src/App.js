import logo from './logo.svg';
import './App.css';
import InputData from './DisplayData';
import DisplayData from './DisplayData';

function App() {
  return (
    <div className="App">
      <h1>Data Entry form</h1>
      <DisplayData/>
    </div>
  );
}

export default App;
